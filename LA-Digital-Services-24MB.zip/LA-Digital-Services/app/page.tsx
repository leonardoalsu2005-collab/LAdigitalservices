"use client";

import dynamic from "next/dynamic";
import { motion, useInView, useReducedMotion } from "framer-motion";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Aperture, AudioLines, BadgeCheck, Bot, Building2, CalendarDays, ChevronDown, CirclePlay, CodeXml, Database,
  Film, Globe, Instagram, Layers3, Menu, MessageCircle, Network, PanelsTopLeft,
  Radar, Send, Target, Workflow, X, Zap, type LucideIcon,
} from "lucide-react";
import { useEffect, useRef, useState, type CSSProperties, type FormEvent } from "react";
import { Button, ButtonLink } from "../components/ui/button";
import AiLab from "../components/ai-lab";
import AutomationLab from "../components/automation-lab";
import WebGallery from "../components/web-gallery";
import MarketingLab from "../components/marketing-lab";
import SocialLab from "../components/social-lab";
import type { Industry } from "../components/demo-industries";
import SiteIntro from "../components/site-intro";

const Orb = dynamic(() => import("../components/orb"), { ssr: false });
const navigation = [["Servicios", "#servicios"], ["IA en acción", "#ia"], ["Proceso", "#proceso"], ["Contacto", "#contacto"]];

const services: { name: string; detail: string; icon: LucideIcon; hue: number; shape: string; angle: number }[] = [
  { name: "Desarrollo Web", detail: "Sitios rápidos y experiencias inmersivas diseñadas para convertir visitas en oportunidades.", icon: PanelsTopLeft, hue: 201, shape: "14px", angle: -9 },
  { name: "Automatización IA", detail: "Conecta tus herramientas y reduce las tareas repetitivas con flujos inteligentes.", icon: Workflow, hue: 155, shape: "50%", angle: 12 },
  { name: "Agente Virtual 24/7", detail: "Responde consultas, califica prospectos y coordina citas en los canales que ya usas.", icon: Bot, hue: 261, shape: "22px 22px 10px 10px", angle: 7 },
  { name: "Publicidad Digital", detail: "Diseño publicitario y campañas en Meta, Google y TikTok con objetivos medibles.", icon: Target, hue: 39, shape: "50%", angle: -14 },
  { name: "Redes Sociales", detail: "Estrategia de contenidos, gestión de comunidad y atención multicanal.", icon: MessageCircle, hue: 330, shape: "24px 24px 24px 6px", angle: -7 },
  { name: "Videos con IA", detail: "Piezas audiovisuales para campañas, redes y presentaciones de producto.", icon: Film, hue: 13, shape: "9px", angle: 10 },
  { name: "Catálogos Digitales", detail: "Vitrinas interactivas para mostrar tus productos y facilitar cada consulta.", icon: Layers3, hue: 84, shape: "10px 22px", angle: -12 },
  { name: "Marketing con Creadores", detail: "Campañas con influencers que conectan tu marca con las audiencias adecuadas.", icon: Aperture, hue: 287, shape: "24px 9px", angle: 12 },
];

const technologies: { name: string; icon: LucideIcon }[] = [
  { name: "ChatGPT", icon: MessageCircle }, { name: "OpenAI", icon: Aperture }, { name: "Meta Ads", icon: Radar },
  { name: "Google Ads", icon: Target }, { name: "WhatsApp", icon: MessageCircle }, { name: "Instagram", icon: Instagram },
  { name: "TikTok", icon: CirclePlay }, { name: "Automatización", icon: Workflow }, { name: "CRM", icon: Database }, { name: "APIs", icon: CodeXml },
];

const steps = [
  ["Analizamos tu negocio", "Identificamos dónde se pierde tiempo y qué oportunidades vale la pena priorizar."],
  ["Diseñamos la estrategia", "Definimos qué construir y cómo medir el avance."],
  ["Implementamos IA", "Configuramos agentes y herramientas con el contexto de tu empresa."],
  ["Automatizamos procesos", "Conectamos canales, equipos y datos en flujos que puedes supervisar."],
  ["Escalamos resultados", "Revisamos el desempeño y ampliamos lo que funciona."],
];

const orbNodes = [
  { label: "Sitios web", icon: CodeXml, x: 23, y: 26, endX: 36, endY: 37 },
  { label: "IA", icon: Bot, x: 73, y: 18, endX: 65, endY: 31 },
  { label: "Marketing", icon: AudioLines, x: 80, y: 49, endX: 71, endY: 49 },
  { label: "Automatización", icon: Workflow, x: 24, y: 75, endX: 35, endY: 65 },
  { label: "Redes sociales", icon: Network, x: 71, y: 81, endX: 63, endY: 67 },
];

function OrbFigure({ scroll, onOpenAi, onOpenAutomation, onOpenWeb, onOpenMarketing, onOpenSocial }: { scroll: { progress: number }; onOpenAi: () => void; onOpenAutomation: () => void; onOpenWeb: () => void; onOpenMarketing: () => void; onOpenSocial: () => void }) {
  const figure = useRef<HTMLDivElement>(null);
  const actions: Record<string, () => void> = { IA: onOpenAi, Automatización: onOpenAutomation, "Sitios web": onOpenWeb, Marketing: onOpenMarketing, "Redes sociales": onOpenSocial };
  const visible = useInView(figure, { amount: 0.12 });
  const reducedMotion = useReducedMotion();

  return <div className="orb-figure" ref={figure}>
    <div className="orb-glow"/>
    <div className="orb-still"/>
    <Orb scroll={scroll}/>
    <div className="orb-flares"><i/><i/><i/><i/></div>
    <svg className="orb-connections" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
      {orbNodes.map(({ label, x, y, endX, endY }) => <g key={label}>
        <path d={`M${x} ${y} L${endX} ${endY}`}/>
        <circle cx={endX} cy={endY} r=".62"/>
      </g>)}
    </svg>
    {orbNodes.map(({ label, icon: Icon, x, y }, index) => <div key={label} className="orb-label-anchor" style={{ left: `${x}%`, top: `${y}%` }}>
      <motion.div className="orb-label-motion" initial={false}
        animate={visible && !reducedMotion ? { y: [0, -6, 0, 5, 0] } : { y: 0 }}
        transition={visible && !reducedMotion ? { duration: 6 + index * .45, delay: index * .18, repeat: Infinity, ease: "easeInOut" } : { duration: 0 }}>
        {actions[label]
          ? <button type="button" className="orb-label orb-label-interactive" aria-haspopup="dialog" onClick={actions[label]}><Icon strokeWidth={1.7} aria-hidden="true"/> {label}</button>
          : <span className="orb-label" aria-hidden="true"><Icon strokeWidth={1.7}/> {label}</span>}
      </motion.div>
    </div>)}
  </div>;
}

function Brand() {
  return <a className="brand" href="#inicio" aria-label="LA Digital Services, inicio">
    <span className="brand-official" aria-hidden="true"/>
    <span>LA Digital <strong>Services</strong></span>
  </a>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const toggle = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") { setOpen(false); toggle.current?.focus(); }
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [open]);
  return <header className="header"><div className="shell header-inner">
    <Brand/>
    <nav id="menu-principal" className={open ? "nav is-open" : "nav"} aria-label="Menú principal">
      {navigation.map(([label, href]) => <a key={href} href={href} onClick={() => setOpen(false)}>{label}</a>)}
      <ButtonLink className="mobile-cta" href="#contacto" size="small" variant="outline" onClick={() => setOpen(false)}>Agenda una reunión</ButtonLink>
    </nav>
    <ButtonLink className="header-cta" href="#contacto" size="small" variant="outline">Agenda una reunión</ButtonLink>
    <button ref={toggle} className="menu-toggle" aria-expanded={open} aria-controls="menu-principal" aria-label={open ? "Cerrar menú" : "Abrir menú"} onClick={() => setOpen(!open)}>
      {open ? <X size={22}/> : <Menu size={22}/>}
    </button>
  </div></header>;
}

function Impact() {
  const ref = useRef<HTMLDivElement>(null);
  const visible = useInView(ref, { once: true, amount: 0.26 });
  const reduced = useReducedMotion();
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!visible) return;
    if (reduced) return;
    let frame = 0;
    const start = performance.now();
    function update(now: number) {
      const progress = Math.min(1, (now - start) / 930);
      setValue(1 - (1 - progress) ** 3);
      if (progress < 1) frame = requestAnimationFrame(update);
    }
    frame = requestAnimationFrame(update);
    return () => cancelAnimationFrame(frame);
  }, [visible, reduced]);
  return <section className="impact" aria-label="Capacidades de LA Digital Services"><div className="shell impact-inner" ref={ref}>
    <div className="metric">
      <strong aria-hidden="true">{visible && !reduced ? "+" + Math.round(24 * value) + "/7" : "+24/7"}</strong>
      <span><span className="sr-only">+24/7 </span>Atención automática</span>
    </div>
    <div className="metric">
      <strong className="metric-campaign">Campaña publicitaria con Ads</strong>
      <span>Más ventas</span>
    </div>
    <div className="metric">
      <strong>IA</strong>
      <span>Automatización general = más fluidez empresarial</span>
    </div>
    <div className="metric">
      <strong className="metric-presence" aria-hidden="true"><Building2 size={27}/><Globe size={16}/></strong>
      <span>Empresa con presencia digital futurista</span>
    </div>
  </div></section>;
}

function Contact({ service, onServiceChange }: { service: string; onServiceChange: (service: string) => void }) {
  const [draft, setDraft] = useState<{ service: string; text: string }>();
  const [copied, setCopied] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    setCopied(false);
    setDraft({ service, text: ["Solicitud para LA Digital Services", "", "Nombre: " + data.get("nombre"), "Email: " + data.get("email"), "Servicio: " + data.get("servicio"), "", String(data.get("proyecto"))].join("\n") });
  }
  return <form className="contact-form" onSubmit={submit}>
    <div className="form-row">
      <label>Nombre<input name="nombre" autoComplete="name" placeholder="Tu nombre" maxLength={120} required/></label>
      <label>Correo electrónico<input name="email" type="email" autoComplete="email" placeholder="tu@empresa.com" maxLength={254} required/></label>
    </div>
    <label>¿Qué servicio te interesa?<span className="select-wrap"><select name="servicio" value={service} onChange={event => { onServiceChange(event.target.value); setDraft(undefined); }} required><option disabled value="">Selecciona un servicio</option>{services.map(({name}) => <option key={name}>{name}</option>)}<option>Otro o varios servicios</option></select><ChevronDown size={16} aria-hidden="true"/></span></label>
    <label>Cuéntanos sobre tu proyecto<textarea name="proyecto" placeholder="¿Qué quieres crear o automatizar?" rows={4} maxLength={2500} required /></label>
    <Button type="submit"><Send size={16}/> Preparar solicitud</Button>
    {draft?.service === service && <div className="draft" role="status">
      <p>Tu solicitud está lista para compartir.</p>
      <div className="draft-actions">
        {typeof navigator !== "undefined" && navigator.clipboard && <Button type="button" variant="outline" size="small" onClick={async () => { try { await navigator.clipboard.writeText(draft.text); setCopied(true); } catch { setCopied(false); } }}>{copied ? "Copiada" : "Copiar solicitud"}</Button>}
        <ButtonLink variant="outline" size="small" download="solicitud-la-digital.txt" href={"data:text/plain;charset=utf-8," + encodeURIComponent(draft.text)}>Descargar solicitud</ButtonLink>
      </div>
    </div>}
  </form>;
}

export default function Home() {
  const main = useRef<HTMLElement>(null);
  const [aiView, setAiView] = useState<"video" | "simulation" | null>(null);
  const [automationOpen, setAutomationOpen] = useState(false);
  const [webOpen, setWebOpen] = useState(false);
  const [marketingOpen, setMarketingOpen] = useState(false);
  const [socialOpen, setSocialOpen] = useState(false);
  const [contactService, setContactService] = useState("");
  const [industry, setIndustry] = useState<Industry>("edificio");
  const orbScroll = useRef({ progress: 0 });
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add("(prefers-reduced-motion: no-preference)", () => {
      gsap.timeline({
        scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: 0.6 },
        defaults: { ease: "none", duration: 1 },
      })
        .to(".orb-figure", { yPercent: 7 }, 0)
        .to(orbScroll.current, { progress: 1 }, 0);
      gsap.from(".orb-label-anchor", {
        autoAlpha: 0, y: 12, duration: .65, stagger: .09, ease: "power2.out",
        scrollTrigger: { trigger: ".orb-figure", start: "top 86%", once: true },
      });
      gsap.utils.toArray<HTMLElement>("[data-reveal]", main.current).forEach((element, index) => {
        gsap.from(element, {
          autoAlpha: 0, y: 27, duration: 0.65, ease: "power2.out",
          delay: element.classList.contains("service-card") ? (index % 4) * .065 : 0,
          scrollTrigger: { trigger: element, start: "top 91%", once: true },
        });
      });
      gsap.fromTo(".process-progress", { scaleX: 0 }, { scaleX: 1, ease: "none", scrollTrigger: { trigger: ".process-list", start: "top 93%", end: "bottom 65%", scrub: 0.5 } });
    });
    return () => media.revert();
  }, []);
  return <>
    <SiteIntro />
    <div id="site-page">
    <a className="skip" href="#contenido">Saltar al contenido</a>
    <Header />
    <main id="contenido" ref={main}>
      <section className="hero" id="inicio" aria-labelledby="hero-title">
        <div className="hero-grid" aria-hidden="true"/>
        <div className="shell hero-inner">
          <div className="hero-copy">
            <h1 id="hero-title">Construímos el futuro digital con <span>Marketing, Inteligencia Artificial y Automatización.</span></h1>
            <div className="hero-actions">
              <ButtonLink className="hero-button" href="#contacto"><CalendarDays size={16} aria-hidden="true"/> Agenda una reunión</ButtonLink>
              <ButtonLink className="hero-button" variant="outline" href="#servicios"><Layers3 size={16} aria-hidden="true"/> Ver servicios</ButtonLink>
            </div>
          </div>
          <OrbFigure scroll={orbScroll.current} onOpenAi={() => setAiView("video")} onOpenAutomation={() => setAutomationOpen(true)} onOpenWeb={() => setWebOpen(true)} onOpenMarketing={() => setMarketingOpen(true)} onOpenSocial={() => setSocialOpen(true)} />
        </div>
      </section>
      <Impact />
      <section id="servicios" className="shell section">
        <div className="section-heading" data-reveal><div className="eyebrow"><span className="eyebrow-line"/> Servicios</div><h2>Sitios que atraen.<br/><em>Sistemas que trabajan.</em></h2><p>Combina web, marketing e inteligencia artificial para que cada canal ayude a tu negocio a crecer.</p></div>
        <div className="service-grid">
          {services.map(({ name, detail, icon: Icon, hue, shape, angle }) => <article className="service-card" key={name} style={{ "--hue": hue, "--icon-shape": shape, "--icon-angle": angle + "deg" } as CSSProperties} data-reveal>
            <div className="service-art" aria-hidden="true"><span className="service-icon"><Icon strokeWidth={1.65}/></span></div>
            <div className="service-copy"><h3>{name}</h3><p>{detail}</p></div>
            <ButtonLink
              className="service-quote"
              variant="outline"
              size="small"
              href="#contacto"
              aria-label={"Cotizar este servicio: " + name}
              onClick={() => setContactService(name)}
            >
              Cotizar este servicio
            </ButtonLink>
          </article>)}
        </div>
      </section>
      <section id="ia" className="demo-section"><div className="shell section demo-layout">
        <div className="section-heading" data-reveal><div className="eyebrow"><span className="eyebrow-line"/> IA en acción</div><h2>Una conversación que <em>mueve tu negocio.</em></h2><p>Explora cómo un agente inteligente responde a una consulta y guía al cliente hacia el siguiente paso.</p><div className="demo-features"><span><MessageCircle size={17}/> Respuestas inmediatas</span><span><Zap size={17}/> Disponible 24/7</span></div></div>
        <div className="ai-demo-entry" data-reveal>
          <div className="ai-lab-symbol"><Bot size={25} aria-hidden="true"/></div>
          <h3>Probá el agente de IA</h3>
          <p>Explorá cinco escenarios empresariales, desde la primera consulta hasta el seguimiento en CRM.</p>
          <Button type="button" aria-haspopup="dialog" onClick={() => setAiView("simulation")}>Abrir simulación</Button>
        </div>
      </div></section>
      <section id="tecnologia" className="shell section tech-section">
        <div className="section-heading" data-reveal><div className="eyebrow"><span className="eyebrow-line"/> Tecnología</div><h2>Tus canales, <em>conectados.</em></h2><p>Integramos IA, publicidad, mensajería y sistemas de ventas según las necesidades de tu empresa.</p></div>
        <div className="tech-grid">{technologies.map(({ name, icon: Icon }) => <div className="tech-tile" key={name} data-reveal><div className="tech-icon"><Icon size={25} strokeWidth={1.45}/></div><span>{name}</span></div>)}</div>
      </section>
      <section id="proceso" className="process-section"><div className="shell section">
        <div className="section-heading" data-reveal><div className="eyebrow"><span className="eyebrow-line"/> Nuestro proceso</div><h2>De la idea <em>a la operación.</em></h2></div>
        <ol className="process-list"><li className="process-progress" aria-hidden="true"/>{steps.map(([title, description], i) => <li className="process-step" key={title} data-reveal><span className="step-number">{String(i + 1).padStart(2, "0")}</span><h3>{title}</h3><p>{description}</p></li>)}</ol>
      </div></section>
      <section id="testimonios" className="shell section testimonial-section">
        <div className="section-heading" data-reveal><div className="eyebrow"><span className="eyebrow-line"/> Testimonios</div><h2>La experiencia <em>de nuestros clientes.</em></h2></div>
        <div className="testimonial-card" data-reveal><div className="testimonial-icon"><BadgeCheck size={26}/></div><p>Próximamente compartiremos testimonios y casos de éxito de nuestros clientes.</p></div>
      </section>
      <section id="contacto" className="contact-section"><div className="shell section contact-layout">
        <div className="section-heading" data-reveal><div className="eyebrow"><span className="eyebrow-line"/> Contacto</div><h2>Hablemos de <em>tu próximo proyecto.</em></h2><p>Prepara una solicitud con lo que quieres crear o automatizar.</p></div>
        <Contact service={contactService} onServiceChange={setContactService} />
      </div></section>
    </main>
    {aiView && <AiLab initialView={aiView} onClose={() => setAiView(null)} />}
    {automationOpen && <AutomationLab onClose={() => setAutomationOpen(false)} />}
    {webOpen && <WebGallery onIndustry={setIndustry} onClose={() => setWebOpen(false)} />}
    {marketingOpen && <MarketingLab onIndustry={setIndustry} industry={industry} onClose={() => setMarketingOpen(false)} />}
    {socialOpen && <SocialLab onIndustry={setIndustry} industry={industry} onClose={() => setSocialOpen(false)} />}
    <footer className="footer"><div className="shell footer-inner"><Brand/><span>© {new Date().getFullYear()} LA Digital Services</span><a href="#inicio">Volver al inicio</a></div></footer>
    </div>
  </>;
}
