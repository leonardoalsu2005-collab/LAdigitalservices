import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "@fontsource-variable/inter";
import { siteUrl } from "./site-url";
import "./globals.css";
import "./site-intro.css";
import "./ai-lab.css";
import "./automation-lab.css";
import "./web-gallery.css";
import "./marketing-lab.css";
import "./social-lab.css";

const title = "LA Digital Services | Web, Marketing e Inteligencia Artificial";
const description = "Creamos sitios web, automatizaciones y agentes inteligentes que trabajan para tu empresa 24 horas al día.";

export const metadata: Metadata = {
  metadataBase: siteUrl(),
  title,
  description,
  keywords: ["LA Digital Services", "diseño web", "desarrollo web", "marketing digital", "inteligencia artificial", "automatización de empresas", "agentes de IA", "gestión de redes sociales"],
  alternates: { canonical: "/" },
  robots: { index: true, follow: true },
  openGraph: {
    type: "website",
    siteName: "LA Digital Services",
    title,
    description,
    url: "/",
    images: [{ url: "/la-digital-services-logo-oficial.jpg", alt: "Logo de LA Digital Services" }],
  },
  icons: [{ rel: "icon", url: "/marca.svg" }],
};
export const viewport: Viewport = { themeColor: "#050505" };

export default function Layout({ children }: { children: ReactNode }) {
  return <html lang="es"><body>{children}</body></html>;
}
