export function siteUrl(): URL {
  const explicitUrl = process.env.SITE_URL?.trim();
  const vercelDomain = process.env.VERCEL_PROJECT_PRODUCTION_URL?.trim();
  if (process.env.VERCEL === "1" && !explicitUrl && !vercelDomain) {
    throw new Error("Configurá SITE_URL con la URL pública de producción o habilitá las variables de sistema de Vercel.");
  }
  const origin = explicitUrl || (vercelDomain
    ? `https://${vercelDomain}`
    : "https://la-digital-services-ia.stoutninja.chatgpt.site");
  const url = new URL(origin);
  if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
    throw new Error("SITE_URL debe ser una URL HTTP o HTTPS en la raíz del dominio.");
  }
  return url;
}
