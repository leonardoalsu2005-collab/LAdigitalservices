# LA Digital Services

Código fuente de la versión 31 publicada en ChatGPT Sites, con configuración de Vercel y metadatos SEO.

## Compilar

Desde la carpeta que contiene `package.json`:

```sh
npm ci
npm run build
```

Next.js genera la página estática, los recursos y los archivos `robots.txt` y `sitemap.xml` en `out/`. Las versiones de las dependencias están en `package-lock.json`.

## Publicar en Vercel

1. Descomprimí el ZIP e importá la carpeta `LA-Digital-Services` desde un repositorio Git en Vercel. Elegí como raíz la carpeta que contiene `vercel.json`.
2. La configuración usa `npm ci`, `npm run build` y la salida `out/`. También podés desplegar desde esa carpeta con `npx vercel --prod`.
3. El SEO toma el dominio de producción de Vercel. Si elegís un dominio específico o desactivás las variables de sistema, configurá `SITE_URL` con la URL HTTPS pública completa (por ejemplo, `https://www.tudominio.com`) y volvé a desplegar.
4. En el enlace público, comprobá que `/sitemap.xml` y `/robots.txt` apunten al dominio que querés posicionar.

Para una compilación local sin variables, se usa como referencia la dirección original de ChatGPT Sites. Si compilás localmente para publicar en otro dominio, definí `SITE_URL` antes de compilar.
