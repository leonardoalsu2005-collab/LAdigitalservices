"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import { useReducedMotion } from "framer-motion";
import { IndustryPicker, industries, type Industry } from "./demo-industries";
import { AudioLines, BarChart3, CalendarDays, Check, Clapperboard, Database, Facebook, Filter, Flame, Image as ImageIcon, Instagram, MousePointer2, Radar, RotateCcw, Snowflake, Target, UserRound, Users, X, Zap } from "lucide-react";

const scenarios = [
  { id: "facebook", label: "Facebook Ads", result: "+50.000 de alcance", icon: Facebook },
  { id: "instagram", label: "Instagram", result: "8.000 seguidores", icon: Instagram },
  { id: "embudo", label: "Embudo de ventas", result: "35 clientes", icon: Filter },
  { id: "leads", label: "Generación de leads", result: "3 niveles de intención", icon: Target },
  { id: "resultados", label: "Resultados", result: "+120% en ventas", icon: BarChart3 },
] as const;
type Scenario = (typeof scenarios)[number];

const formatNumber = (value: number) => Math.round(value).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
const scale = (progress: number, start: number, end: number) => Math.min(1, Math.max(0, (progress - start) / (end - start)));

function MetricCards({ data }: { data: { label: string; value: string; origin?: string }[] }) {
  return <dl className="mk-metrics">{data.map(({ label, value, origin }) => <div key={label}>
    <dt>{label}</dt><dd>{value}</dd>{origin && <dd className="mk-origin">Desde {origin}</dd>}
  </div>)}</dl>;
}

function CampaignTrend({ progress, label }: { progress: number; label: string }) {
  return <svg className="mk-trend" viewBox="0 0 300 104" role="img" aria-label={label}>
    <path className="mk-trend-grid" d="M0 24H300M0 49H300M0 74H300M0 99H300M40 0V104M100 0V104M160 0V104M220 0V104M280 0V104" />
    <path className="mk-trend-area" d="M0 96L37 87L78 91L120 64L155 68L197 42L236 49L269 22L300 9V104H0Z" style={{ opacity: progress * .7 }}/>
    <path className="mk-trend-line" pathLength="1" strokeDasharray="1" strokeDashoffset={1 - progress} d="M0 96L37 87L78 91L120 64L155 68L197 42L236 49L269 22L300 9"/>
  </svg>;
}

function FacebookCampaign({ progress, industry }: { progress: number; industry: Industry }) {
  const business = industries[industry];
  return <div className="mk-columns">
    <article className="ai-lab-panel mk-feed">
      <div className="ai-panel-heading"><Facebook size={18} aria-hidden="true"/> Vista del feed <span>Publicidad</span></div>
      <div className="mk-ad">
        <div className="mk-ad-profile"><span>{business.brand[0]}</span><div><strong>{business.brand}</strong><small>Anuncio de muestra</small></div></div>
        <img src={"/galeria-web/" + business.photo + ".webp"} alt={business.offer} width="480" height="480"/>
        <div className="mk-ad-copy"><div><strong>{business.campaign}</strong><small>{business.offer}</small></div><span>{business.action}</span></div>
      </div>
    </article>
    <section className="ai-lab-panel mk-data" aria-label="Métricas de Facebook Ads">
      <div className="ai-panel-heading"><Radar size={18} aria-hidden="true"/> Rendimiento de campaña</div>
      <MetricCards data={[
        { label: "Alcance", value: "+" + formatNumber(50000 * scale(progress, 0, .86)) },
        { label: "Clics", value: "+" + formatNumber(1200 * scale(progress, .1, .9)) },
        { label: "Leads", value: "+" + formatNumber(180 * scale(progress, .19, .95)) },
        { label: "Conversiones", value: "+" + formatNumber(35 * scale(progress, .3, 1)) },
      ]}/>
      <CampaignTrend progress={progress} label="Evolución ilustrativa de la campaña"/>
    </section>
  </div>;
}

const formats = [{ label: "Publicaciones", icon: ImageIcon }, { label: "Historias", icon: Instagram }, { label: "Reels", icon: Clapperboard }];

function InstagramCampaign({ progress, industry }: { progress: number; industry: Industry }) {
  const business = industries[industry];
  const photo = "/galeria-web/" + business.photo + ".webp";
  const [format, setFormat] = useState(formats[0].label);
  return <div className="mk-columns">
    <section className="ai-lab-panel" aria-label="Perfil empresarial de muestra">
      <div className="ai-panel-heading"><Instagram size={18} aria-hidden="true"/> Instagram <span>Perfil empresarial</span></div>
      <div className="mk-profile">
        <div className="mk-profile-id"><span className="mk-profile-avatar"><img src={photo} alt="" width={48} height={48}/></span><strong>{business.brand}</strong></div>
        <div className="mk-stories">{business.highlights.map(label => <button type="button" key={label} onClick={() => setFormat("Historias")} aria-label={"Ver historias de " + label}><img src={photo} alt="" width={42} height={42}/><span>{label}</span></button>)}</div>
        <div className="mk-formats" role="group" aria-label="Formato de Instagram">
          {formats.map(({ label, icon: Icon }) => <button key={label} type="button" aria-pressed={format === label} onClick={() => setFormat(label)}><Icon size={15} aria-hidden="true"/> {label}</button>)}
        </div>
        <div className="mk-posts" key={format} data-format={format} aria-label={format}>
          {business.posts.map((label, i) => <figure key={label} style={{ animationDelay: i * .12 + "s" }}>
            <img src={photo} alt={label} width={120} height={120} style={{ objectPosition: (25 + i * 25) + "% center" }}/>
            {format === "Reels" && <Clapperboard size={17} aria-hidden="true"/>}
            {format !== "Publicaciones" && <figcaption>{label}</figcaption>}
          </figure>)}
        </div>
      </div>
    </section>
    <section className="ai-lab-panel mk-data" aria-label="Crecimiento en Instagram">
      <div className="ai-panel-heading"><BarChart3 size={18} aria-hidden="true"/> Crecimiento del perfil</div>
      <MetricCards data={[
        { label: "Seguidores", origin: "1.500", value: formatNumber(1500 + 6500 * progress) },
        { label: "Alcance", origin: "10.000", value: formatNumber(10000 + 110000 * progress) },
        { label: "Interacciones", origin: "500", value: formatNumber(500 + 8500 * progress) },
      ]}/>
      <CampaignTrend progress={progress} label="Crecimiento ilustrativo de Instagram"/>
    </section>
  </div>;
}

const funnel = [
  { title: "Tráfico", count: 5000, icon: MousePointer2 },
  { title: "Interés", count: 1200, icon: Radar },
  { title: "Contactos", count: 180, icon: Users },
  { title: "Clientes", count: 35, icon: Check },
];

function SalesFunnel({ progress }: { progress: number }) {
  return <section className="ai-lab-panel mk-funnel-panel" aria-label="Embudo de ventas">
    <div className="mk-funnel">
      <div className="mk-funnel-track" aria-hidden="true">
        {[0, 1, 2].map(i => <span key={i} style={{ "--person-delay": i * .24 + "s" } as CSSProperties}><UserRound size={17}/></span>)}
      </div>
      <ol>{funnel.map(({ title, count, icon: Icon }, i) => {
        const phase = scale(progress, i * .21, i * .21 + .37);
        return <li key={title} style={{ "--slice": (100 - i * 15) + "%" } as CSSProperties} data-on={phase > 0}>
          <Icon size={18} aria-hidden="true"/><span>{title}</span><strong>{formatNumber(count * phase)}</strong>
        </li>;
      })}</ol>
    </div>
  </section>;
}

const leadRows = [
  { name: "Prospecto A", level: "Lead caliente", icon: Flame, tone: "warm" },
  { name: "Prospecto B", level: "Lead medio", icon: Zap, tone: "mid" },
  { name: "Prospecto C", level: "Lead frío", icon: Snowflake, tone: "cool" },
];

function LeadRouting({ progress, industry }: { progress: number; industry: Industry }) {
  return <section className="ai-lab-panel mk-routing" aria-label="Clasificación de prospectos">
    <div className="mk-route" aria-label="Del anuncio al CRM y a la clasificación por IA">
      {[{ name: "Anuncios", icon: Target }, { name: "CRM", icon: Database }, { name: "Clasificación IA", icon: AudioLines }].map(({ name, icon: Icon }, index) => <div key={name} data-on={progress >= index * .2}>
        <Icon size={21} aria-hidden="true"/><span>{name}</span>
      </div>)}
    </div>
    <ul className="mk-leadlist">
      {leadRows.map(({ name, level, icon: Icon, tone }, i) => {
        const entered = progress > .2 + i * .12;
        const classified = progress > .5 + i * .13;
        return <li key={name} data-entered={entered}>
          <UserRound size={18} aria-hidden="true"/><div><strong>{entered ? name : "Esperando prospecto"}</strong><small>{entered ? industries[industry].signals[i] : "En cola"}</small></div>
          {classified ? <span data-tone={tone}><Icon size={15} aria-hidden="true"/> {level}</span> : <span>En proceso</span>}
        </li>;
      })}
    </ul>
  </section>;
}

function ResultsBoard({ progress }: { progress: number }) {
  const metrics = [{ label: "Visibilidad", value: 300 }, { label: "Contactos", value: 180 }, { label: "Ventas", value: 120 }];
  return <div className="mk-columns">
    <section className="ai-lab-panel mk-data" aria-label="Indicadores empresariales">
      <div className="ai-panel-heading"><BarChart3 size={18} aria-hidden="true"/> Variación de indicadores</div>
      <div className="mk-bars">{metrics.map(({ label, value }) => <div key={label}><span>{label}</span><strong>+{formatNumber(progress * value)}%</strong><div><i style={{ width: progress * value / 3 + "%" }}/></div></div>)}</div>
    </section>
    <section className="ai-lab-panel mk-data" aria-label="Captación automatizada">
      <div className="ai-panel-heading"><CalendarDays size={18} aria-hidden="true"/> Captación automatizada</div>
      <MetricCards data={[{ label: "Disponibilidad del sistema", value: progress > .58 ? "+24/7" : "—" }]}/>
      <CampaignTrend progress={progress} label="Tendencia ilustrativa de captación de clientes"/>
    </section>
  </div>;
}

function MarketingRun({ scenario, industry }: { scenario: Scenario; industry: Industry }) {
  const reduceMotion = useReducedMotion();
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    if (reduceMotion) return;
    const start = performance.now();
    const timer = window.setInterval(() => {
      const next = Math.min(1, (performance.now() - start) / 4500);
      setProgress(next);
      if (next === 1) window.clearInterval(timer);
    }, 45);
    return () => window.clearInterval(timer);
  }, [reduceMotion]);
  const value = reduceMotion ? 1 : progress;
  return <div className="mk-run">
    <div className="mk-progress" role="progressbar" aria-label="Progreso de la simulación" aria-valuenow={Math.round(value * 100)} aria-valuemin={0} aria-valuemax={100}><i style={{ width: value * 100 + "%" }}/></div>
    {scenario.id === "facebook" && <FacebookCampaign progress={value} industry={industry}/>}
    {scenario.id === "instagram" && <InstagramCampaign progress={value} industry={industry}/>}
    {scenario.id === "embudo" && <SalesFunnel progress={value}/>}
    {scenario.id === "leads" && <LeadRouting progress={value} industry={industry}/>}
    {scenario.id === "resultados" && <ResultsBoard progress={value}/>}
    <span className="sr-only" role="status">{value === 1 ? "Simulación completada" : ""}</span>
  </div>;
}

export default function MarketingLab({ onClose, industry, onIndustry }: { onClose: () => void; industry: Industry; onIndustry: (value: Industry) => void }) {
  const modal = useRef<HTMLDialogElement>(null);
  const [scenario, setScenario] = useState<Scenario>(scenarios[0]);
  const [replay, setReplay] = useState(0);
  useEffect(() => {
    const dialog = modal.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);

  return <dialog className="ai-lab mk-lab" ref={modal} aria-labelledby="mk-title" onClose={onClose}>
    <div className="ai-lab-inner">
      <div className="mk-orb" aria-hidden="true"/>
      <header className="ai-lab-header">
        <div className="ai-lab-symbol"><AudioLines size={24} aria-hidden="true"/></div>
        <div className="ai-lab-title"><h2 id="mk-title">Marketing digital</h2><p>Centro de control · Datos simulados</p></div>
        <button type="button" className="ai-lab-icon" aria-label="Repetir campaña" onClick={() => setReplay(replay + 1)}><RotateCcw size={18} aria-hidden="true"/></button>
        <button type="button" className="ai-lab-icon" aria-label="Cerrar marketing" onClick={() => modal.current?.close()}><X size={21} aria-hidden="true"/></button>
      </header>
      <IndustryPicker industry={industry} onChange={onIndustry}/>
      <div className="mk-scenarios" role="group" aria-label="Demostraciones de marketing">
        {scenarios.map(item => <button type="button" key={item.id} aria-pressed={scenario.id === item.id} onClick={() => setScenario(item)}>
          <item.icon size={17} aria-hidden="true"/><strong>{item.label}</strong>
          <small>{item.result}</small>
          <span className="mk-minichart" aria-hidden="true"><i/><i/><i/><i/></span>
        </button>)}
      </div>
      <MarketingRun key={industry + scenario.id + replay} scenario={scenario} industry={industry}/>
    </div>
  </dialog>;
}
