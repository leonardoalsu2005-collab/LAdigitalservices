"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { Component, useEffect, useMemo, useRef, useState, type RefObject, type ReactNode } from "react";
import * as THREE from "three";

function randomGenerator(seed: number) {
  return () => {
    seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

function neuralGeometry() {
  const rand = randomGenerator(1771);
  const radius = 2.08;
  const golden = Math.PI * (3 - Math.sqrt(5));
  const nodes = Array.from({ length: 470 }, (_, i) => {
    const y = 1 - (2 * (i + 0.5)) / 470;
    const azimuth = i * golden + (rand() - 0.5) * 0.14;
    const ring = Math.sqrt(1 - y * y);
    return new THREE.Vector3(Math.cos(azimuth) * ring, y, Math.sin(azimuth) * ring).multiplyScalar(radius + (rand() - 0.5) * 0.17);
  });
  const lines: number[] = [];
  const particles: number[] = [];
  const sparks: number[] = [];
  const dust: number[] = [];
  const tracks: [THREE.Vector3, THREE.Vector3][] = [];
  nodes.forEach((point, index) => {
    particles.push(...point);
    if (rand() < 0.22) sparks.push(...point);
    for (let other = index + 1; other < nodes.length; other++) {
      const destination = nodes[other];
      if (point.distanceToSquared(destination) < 0.237 && rand() < 0.79) {
        lines.push(...point, ...destination);
        if (rand() < 0.08) tracks.push([point, destination]);
      }
    }
  });
  for (let index = 0; index < 710; index++) {
    const a = rand() * Math.PI * 2;
    const y = rand() * 2 - 1;
    const r = radius * (0.25 + rand() * 0.76);
    const ring = Math.sqrt(1 - y * y);
    particles.push(r * ring * Math.cos(a), r * y, r * ring * Math.sin(a));
  }
  for (let index = 0; index < 235; index++) {
    const r = 2.32 + rand() * 2.55;
    const a = rand() * Math.PI * 2;
    dust.push(r * Math.cos(a), (rand() - 0.5) * 5.8, r * Math.sin(a));
  }
  const rings = [-0.29, 0.23, 0.59].map((tilt, i) => {
    const points = Array.from({ length: 199 }, (_, j) => {
      const angle = (j / 198) * Math.PI * 2;
      return new THREE.Vector3(Math.cos(angle) * (2.49 + i * .22), 0, Math.sin(angle) * (2.49 + i * .22))
        .applyAxisAngle(new THREE.Vector3(0, 0, 1), tilt)
        .applyAxisAngle(new THREE.Vector3(1, 0, 0), 0.54 - i * .33);
    });
    const values = [];
    for (let j = 1; j < points.length; j++) {
      if ((j + i * 11) % 27 < 20) values.push(...points[j - 1], ...points[j]);
    }
    return values;
  });
  return { lines, particles, sparks, dust, tracks, rings };
}

function Geometry({ values, dynamic = false }: { values: number[]; dynamic?: boolean }) {
  const data = useMemo(() => new Float32Array(values), [values]);
  return <bufferGeometry><bufferAttribute attach="attributes-position" args={[data, 3]} usage={dynamic ? THREE.DynamicDrawUsage : THREE.StaticDrawUsage} /></bufferGeometry>;
}

type ScrollProgress = { progress: number };

function Network({ reduceMotion, scroll }: { reduceMotion: boolean; scroll: ScrollProgress }) {
  const { lines, particles, sparks, dust, rings, tracks } = useMemo(neuralGeometry, []);
  const packets = useMemo(() => Array<number>(tracks.length * 3).fill(0), [tracks]);
  const group = useRef<THREE.Group>(null!);
  const packetPoints = useRef<THREE.Points>(null!);
  const idleRotation = useRef(-0.1);
  const orbit = useRef<THREE.Group>(null!);
  const ambient = useRef<THREE.Points>(null!);
  const pointer = useRef({ x: 0, y: 0 });
  useEffect(() => {
    if (reduceMotion) return;
    const move = (event: PointerEvent) => {
      if (event.pointerType !== "mouse") return;
      pointer.current.x = (event.clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = (event.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => window.removeEventListener("pointermove", move);
  }, [reduceMotion]);
  useFrame(({ clock }, delta) => {
    const time = reduceMotion ? 0.9 : clock.elapsedTime;
    if (!reduceMotion) {
      idleRotation.current += Math.min(delta, 0.05) * 0.175;
      group.current.rotation.y = idleRotation.current + scroll.progress * 2.2;
      group.current.rotation.x = THREE.MathUtils.damp(group.current.rotation.x, 0.12 + pointer.current.y * 0.19, 2.3, delta);
      group.current.rotation.z = THREE.MathUtils.damp(group.current.rotation.z, -0.15 + pointer.current.x * 0.16, 2.3, delta);
      orbit.current.rotation.y = time * -0.072 + scroll.progress * 0.6;
      ambient.current.rotation.y = time * 0.028;
    }
    const attr = packetPoints.current.geometry.attributes.position;
    tracks.forEach(([start, end], i) => {
      const t = (time * (0.34 + (i % 9) * 0.05) + i * 0.173) % 1;
      attr.setXYZ(i, THREE.MathUtils.lerp(start.x, end.x, t), THREE.MathUtils.lerp(start.y, end.y, t), THREE.MathUtils.lerp(start.z, end.z, t));
    });
    attr.needsUpdate = true;
  });
  return <>
    <points ref={ambient}><Geometry values={dust}/><pointsMaterial color="#36a5ff" size={0.024} transparent opacity={0.53} blending={THREE.AdditiveBlending} depthWrite={false} /></points>
    <group ref={orbit} rotation={[0.14, 0.22, -0.2]}>
      {rings.map((ring, i) => <lineSegments key={i}><Geometry values={ring}/><lineBasicMaterial color={i === 0 ? "#57d6ff" : "#1870fc"} transparent opacity={i === 0 ? 0.44 : 0.29} blending={THREE.AdditiveBlending} depthWrite={false}/></lineSegments>)}
    </group>
    <group ref={group} rotation={[0.24, -0.1, -0.15]}>
      <lineSegments><Geometry values={lines}/><lineBasicMaterial color="#148dfc" transparent opacity={0.43} blending={THREE.AdditiveBlending} depthWrite={false}/></lineSegments>
      <points><Geometry values={particles}/><pointsMaterial color="#318fff" size={0.022} transparent opacity={0.73} blending={THREE.AdditiveBlending} depthWrite={false}/></points>
      <points><Geometry values={sparks}/><pointsMaterial color="#64e4ff" size={0.034} transparent opacity={0.8} blending={THREE.AdditiveBlending} depthWrite={false}/></points>
      <points ref={packetPoints} frustumCulled={false}><Geometry values={packets} dynamic/><pointsMaterial color="#a6f2ff" size={0.053} transparent opacity={0.98} blending={THREE.AdditiveBlending} depthWrite={false}/></points>
    </group>
  </>;
}

class GraphicsBoundary extends Component<{ children: ReactNode; fallback: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? this.props.fallback : this.props.children; }
}

function ProjectedNetwork({ visible, reduced, onReady, scroll }: { visible: boolean; reduced: boolean; onReady: (ready: boolean) => void; scroll: ScrollProgress }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const { lines, sparks, particles, rings, dust } = useMemo(neuralGeometry, []);
  useEffect(() => {
    const canvas = ref.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context) return;
    const pointer = { x: 0, y: 0 };
    let rotateX = 0.17;
    let rotateY = 0;
    let centerX = 0;
    let centerY = 0;
    let scale = 1;
    let frame = 0;
    let previous = 0;
    const project = (values: number[], i: number, sin: number, cos: number) => {
      const x = values[i] * cos + values[i + 2] * sin;
      const depth = -values[i] * sin + values[i + 2] * cos;
      const y = values[i + 1] * Math.cos(rotateX) - depth * Math.sin(rotateX);
      const z = values[i + 1] * Math.sin(rotateX) + depth * Math.cos(rotateX);
      const perspective = scale * 8.6 / (8.6 - z);
      return [centerX + x * perspective, centerY - y * perspective, z];
    };
    function render(now: number) {
      if (!context || !canvas) return;
      const time = reduced ? 0 : now * 0.001;
      const angle = rotateY + (reduced ? 0 : scroll.progress * 2.2);
      const sin = Math.sin(angle);
      const cos = Math.cos(angle);
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.globalCompositeOperation = "lighter";
      const drawLines = (values: number[], color: string) => {
        context.strokeStyle = color;
        context.beginPath();
        for (let i = 0; i < values.length; i += 6) {
          const start = project(values, i, sin, cos);
          const end = project(values, i + 3, sin, cos);
          context.moveTo(start[0], start[1]);
          context.lineTo(end[0], end[1]);
        }
        context.stroke();
      };
      const drawPoints = (values: number[], color: string, size: number) => {
        context.fillStyle = color;
        context.beginPath();
        for (let i = 0; i < values.length; i += 3) {
          const [x, y, z] = project(values, i, sin, cos);
          const radius = size * (Math.max(0.25, 0.75 + (z + 2.1) * 0.10));
          context.moveTo(x + radius, y);
          context.arc(x, y, radius, 0, Math.PI * 2);
        }
        context.fill();
      };
      context.lineWidth = 0.75;
      drawLines(lines, "rgba(23,132,255,.31)");
      rings.forEach(values => drawLines(values, "rgba(52,160,248,.19)"));
      drawPoints(dust, "rgba(32,153,253,.28)", 1.05);
      drawPoints(particles, "rgba(49,160,255,.48)", 1.25);
      drawPoints(sparks, "rgba(99,227,255,.30)", 3.1);
      drawPoints(sparks, "rgba(146,233,255,.66)", 1.48 + Math.sin(time * 1.6) * .22);
    }
    function animate(now: number) {
      const delta = previous ? Math.min(60, now - previous) : 16;
      if (!previous || now - previous >= 29) {
        rotateY += delta * (0.00018 + pointer.x * 0.00007);
        rotateX += (0.17 + pointer.y * 0.22 - rotateX) * 0.055;
        render(now);
        previous = now;
      }
      frame = requestAnimationFrame(animate);
    }
    const resize = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect;
      const dpr = Math.min(1.4, window.devicePixelRatio);
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      centerX = canvas.width / 2;
      centerY = canvas.height / 2;
      scale = Math.min(canvas.height * .151, canvas.width * .213);
      render(performance.now());
      onReady(true);
    });
    const move = (event: PointerEvent) => {
      if (event.pointerType !== "mouse") return;
      pointer.x = event.clientX / window.innerWidth * 2 - 1;
      pointer.y = event.clientY / window.innerHeight * 2 - 1;
    };
    resize.observe(canvas);
    if (visible && !reduced) {
      window.addEventListener("pointermove", move, { passive: true });
      frame = requestAnimationFrame(animate);
    }
    return () => {
      resize.disconnect();
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", move);
    };
  }, [visible, reduced, onReady, lines, sparks, particles, rings, dust, scroll]);
  return <canvas className="orb-projection" ref={ref} />;
}

export default function Orb({ scroll }: { scroll: ScrollProgress }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visibility, setReady] = useVisibility(ref);
  const [webgl, setWebgl] = useState<boolean | null>(null);
  useEffect(() => {
    const context = document.createElement("canvas").getContext("webgl2");
    if (context) context.getExtension("WEBGL_lose_context")?.loseContext();
    setWebgl(Boolean(context));
  }, []);
  const projection = <ProjectedNetwork visible={visibility.visible} reduced={visibility.reduced} onReady={setReady} scroll={scroll}/>;
  return <div className="orb-canvas" ref={ref} data-rendered={visibility.ready}>
    {webgl === false && projection}
    {webgl && <GraphicsBoundary fallback={projection}>
      <Canvas camera={{ position: [0, 0, 8.6], fov: 42 }} dpr={[1, 1.5]} gl={{ alpha: true, antialias: true, powerPreference: "low-power" }}
        frameloop={visibility.visible && !visibility.reduced ? "always" : "demand"}
        onCreated={() => setReady(true)}>
        <Network reduceMotion={visibility.reduced} scroll={scroll} />
      </Canvas>
    </GraphicsBoundary>}
  </div>;
}

function useVisibility(ref: RefObject<HTMLDivElement | null>) {
  const [ready, setReady] = useState(false);
  const [visible, setVisible] = useState(true);
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(media.matches);
    update();
    media.addEventListener("change", update);
    const observer = new IntersectionObserver(([entry]) => setVisible(entry.isIntersecting));
    if (ref.current) observer.observe(ref.current);
    return () => { observer.disconnect(); media.removeEventListener("change", update); };
  }, [ref]);
  return [{ ready, visible, reduced }, setReady] as const;
}
