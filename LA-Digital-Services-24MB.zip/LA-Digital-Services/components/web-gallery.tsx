"use client";

import { useLayoutEffect, useRef, useState, type CSSProperties } from "react";
import { ArrowLeft, CalendarDays, Check, CodeXml, Plus, X } from "lucide-react";

import { DemoReference, industries, type Industry } from "./demo-industries";

const exampleVideos = {
  edificio: { path: "/proyectos/torre-video-ejemplo", label: "Video de ejemplo de Torre Vértice", aspectRatio: "530 / 512" },
  vehiculos: { path: "/proyectos/bmw-video-ejemplo", label: "Video de ejemplo de BMW Bolivia", aspectRatio: "512 / 580" },
  restaurante: { path: "/proyectos/restaurante-video-ejemplo", label: "Video de ejemplo de Brasa & Olivo", aspectRatio: "562 / 512" },
};

const examples = [
  { id: "edificio", name: "Edificio residencial", line: "De la vista a la visita.", benefits: ["Más consultas", "Visitas agendadas"], tabs: ["Video de ejemplo", "Departamentos", "Agendar visita"], x: 18, y: 55, tilt: -15 },
  { id: "vehiculos", name: "BMW Bolivia", line: "Del catálogo a la visita.", benefits: ["Más consultas", "Visitas agendadas"], tabs: ["Video de ejemplo", "Modelos", "Agendar visita"], x: 50, y: 38, tilt: 0 },
  { id: "restaurante", name: "Restaurante premium", line: "Más reservas. Mejor experiencia.", benefits: ["Más clientes", "Reservas en línea"], tabs: ["Video de ejemplo", "Menú digital", "Reservas"], x: 82, y: 55, tilt: 15 },
].map(item => ({ ...item, ...industries[item.id as Industry], id: item.id as Industry }));

type Example = (typeof examples)[number];

const apartments = [
  { title: "Suite panorámica", floor: 14, rooms: 1, area: 48 },
  { title: "Residencia alta", floor: 20, rooms: 2, area: 79 },
  { title: "Penthouse terraza", floor: 31, rooms: 3, area: 129 },
];
function DemoForm({ kind, title = "Contacto" }: { kind: "reserva" | "visita"; title?: string }) {
  const [submitted, setSubmitted] = useState(false);
  const timeOptions = kind === "reserva" ? ["18:30", "19:30", "20:30"] : ["10:00", "14:00", "16:00"];
  const action = kind === "reserva" ? "reserva" : "visita";
  return <form className="wg-form" onSubmit={event => { event.preventDefault(); setSubmitted(true); }}>
    <h4>{title}</h4>
    <div className="wg-form-row">
      <label>Fecha<input type="date" required/></label>
      <label>Horario<select>{timeOptions.map(time => <option key={time}>{time}</option>)}</select></label>
    </div>
    {kind === "reserva" ? <label>Personas<select defaultValue="2"><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option></select></label> : <label>Comentario opcional<textarea rows={2} placeholder="¿Cómo podemos ayudarte?"/></label>}
    <button type="submit" className="wg-demo-action">Simular {action}</button>
    {submitted && <p className="wg-confirm" role="status"><Check size={16} aria-hidden="true"/>Simulación confirmada.</p>}
  </form>;
}

function Properties({ onContact }: { onContact: () => void }) {
  const [rooms, setRooms] = useState("");
  return <>
    <div className="wg-filters"><label>Dormitorios<select value={rooms} onChange={event => setRooms(event.target.value)}><option value="">Todos</option><option value="1">1 dormitorio</option><option value="2">2 dormitorios</option><option value="3">3 dormitorios</option></select></label></div>
    <div className="wg-list-cards" aria-live="polite">
      {apartments.filter(item => !rooms || item.rooms === Number(rooms)).map(item => <article className="wg-list-card wg-scroll-card" key={item.title}>
        <div><span>Piso {item.floor} · {item.area} m²</span><h4>{item.title}</h4><p>{item.rooms} {item.rooms === 1 ? "dormitorio" : "dormitorios"}</p><button type="button" className="wg-demo-action" onClick={onContact}>Agendar visita</button></div>
      </article>)}
    </div>
  </>;
}

const bmwModels = [
  { name: "M4 Coupé", category: "Deportivo" },
  { name: "X7", category: "SUV" },
  { name: "i7", category: "Eléctrico" },
];

function Models({ onContact }: { onContact: () => void }) {
  const [category, setCategory] = useState("");

  return <>
    <div className="wg-filters">
      <label>Tipo de vehículo
        <select value={category} onChange={event => setCategory(event.target.value)}>
          <option value="">Todos</option>
          {bmwModels.map(model => <option key={model.category}>{model.category}</option>)}
        </select>
      </label>
    </div>
    <div className="wg-list-cards" aria-live="polite">
      {bmwModels.filter(model => !category || model.category === category).map(model => (
        <article className="wg-list-card wg-scroll-card" key={model.name}>
          <div>
            <span>{model.category}</span>
            <h4>{model.name}</h4>
            <button type="button" className="wg-demo-action" onClick={onContact}>Agendar visita</button>
          </div>
        </article>
      ))}
    </div>
  </>;
}

function Preview({ item }: { item: Example }) {
  const [tab, setTab] = useState(0);
  const isBmw = item.id === "vehiculos";
  const video = exampleVideos[item.id];
  const accent = isBmw ? industries.edificio.color : item.color;

  return <div className="wg-browser" data-template={item.id} style={{ "--wg-accent": accent } as CSSProperties}>
    <div className="wg-browser-header"><span className="wg-window-dots" aria-hidden="true"><i/><i/><i/></span><strong>{isBmw ? item.name : item.brand}</strong><span>Prototipo</span></div>
    <nav className="wg-preview-nav" aria-label="Secciones del sitio de muestra">
      {item.tabs.map((label, index) => <button type="button" key={label} aria-pressed={tab === index} onClick={() => setTab(index)}>{label}</button>)}
    </nav>
    {tab === 0 && (
      <video
        className="wg-example-video"
        style={{ aspectRatio: video.aspectRatio }}
        controls
        playsInline
        preload="metadata"
        poster={video.path + ".webp"}
        aria-label={video.label}
      >
        <source src={video.path + ".mp4"} type="video/mp4"/>
        Tu navegador no puede reproducir este video.
      </video>
    )}
    {tab !== 0 &&
      <div className="wg-preview-content" key={tab} tabIndex={0} aria-label={item.tabs[tab]}>
        {item.id === "restaurante" && (tab === 1
          ? <div className="wg-menu"><h4>Menú de temporada</h4><dl>
            <div><dt>Ensalada de la huerta</dt><dd>Bs 45</dd></div><div><dt>Pesca a la brasa</dt><dd>Bs 105</dd></div><div><dt>Cacao y frutos rojos</dt><dd>Bs 38</dd></div>
          </dl><button type="button" className="wg-demo-action" onClick={() => setTab(2)}>Reservar mesa</button></div>
          : <DemoForm kind="reserva" title="Reservá tu mesa"/>)}
        {item.id === "edificio" && (tab === 1 ? <Properties onContact={() => setTab(2)}/> : <DemoForm kind="visita" title="Agendá una visita a la torre"/>)}
        {isBmw && (tab === 1 ? <Models onContact={() => setTab(2)}/> : <DemoForm kind="visita" title="Agendá una visita a BMW Bolivia"/>)}
      </div>}
  </div>;
}

export default function WebGallery({ onClose, onIndustry }: { onClose: () => void; onIndustry: (value: Industry) => void }) {
  const modal = useRef<HTMLDialogElement>(null);
  const shot = useRef<HTMLDivElement>(null);
  const [selected, setSelected] = useState<Example>();
  const chooseFocus = useRef<HTMLButtonElement>(null);
  const lastCard = useRef<string>("");

  useLayoutEffect(() => {
    const dialog = modal.current;
    if (dialog && !dialog.open) dialog.showModal();

    const original = document.querySelector(".orb-figure")?.getBoundingClientRect();
    const stage = shot.current;
    const frame = stage?.getBoundingClientRect();
    if (stage && original && frame) {
      stage.style.setProperty("--entry-x", original.left + original.width / 2 - frame.left - frame.width / 2 + "px");
      stage.style.setProperty("--entry-y", original.top + original.height / 2 - frame.top - frame.height / 2 + "px");
    }
  }, []);

  useLayoutEffect(() => {
    if (selected) {
      chooseFocus.current?.focus();
      modal.current?.scrollTo({ top: 0, behavior: "instant" });
    } else if (lastCard.current) {
      modal.current?.querySelector<HTMLButtonElement>('[data-project="' + lastCard.current + '"]')?.focus();
    }
  }, [selected]);

  return <dialog className="ai-lab wg-gallery" ref={modal} aria-labelledby="wg-title" onClose={onClose}>
    <div className="ai-lab-inner">
      <header className="ai-lab-header">
        <div className="ai-lab-symbol"><CodeXml size={24} aria-hidden="true"/></div>
        <div className="ai-lab-title"><h2 id="wg-title">Sitios web</h2><p>Galería interactiva</p></div>
        <button type="button" className="ai-lab-icon" aria-label="Cerrar galería" onClick={() => modal.current?.close()}><X size={21} aria-hidden="true"/></button>
      </header>
      {selected ? <div className="wg-selected">
        <div className="wg-selected-heading">
          <button type="button" ref={chooseFocus} className="wg-back" onClick={() => setSelected(undefined)}><ArrowLeft size={17} aria-hidden="true"/> Volver a la galería</button>
          <h3>{selected.name}</h3>
          <p>{selected.line}</p>
          {selected.id !== "edificio" && <DemoReference industry={selected.id}/>}
        </div>
        <Preview key={selected.id} item={selected}/>
      </div> : <div className="wg-stage" ref={shot}>
        <div className="wg-orbits" aria-hidden="true"/>
        <div className="wg-core-motion" aria-hidden="true"><div className="wg-core"/></div>
        {examples.map((item, index) => {
          const isBmw = item.id === "vehiculos";
          const cardName = isBmw ? "Concesionaria de vehículos" : item.name;
          const cover = <>
            <span className="wg-mock-chrome" aria-hidden="true"><i/><i/><i/><span>{isBmw ? "Sitio publicado" : item.brand}</span></span>
            <span className="wg-screen-image" aria-hidden="true"><img src={isBmw ? exampleVideos.vehiculos.path + ".webp" : "/galeria-web/" + item.photo + ".webp"} alt="" width={480} height={360}/>{!isBmw && <span>{item.hero}</span>}</span>
            <span className="wg-screen-label"><item.icon size={15} aria-hidden="true"/> {cardName}</span>
          </>;
          return <div className="wg-screen-position" key={item.id} style={{ "--px": item.x + "%", "--py": item.y + "%", "--angle": item.tilt + "deg", "--stagger": index * .065 + "s", "--wg-accent": item.color } as CSSProperties}>
            <div className="wg-screen-float">
              <button type="button" className={isBmw ? "wg-bmw-card" : "wg-screen"} data-project={item.id} onClick={() => {
                onIndustry(item.id);
                lastCard.current = item.id;
                setSelected(item);
              }}>
                {isBmw ? <span className="wg-screen">{cover}</span> : <>
                  {cover}
                  <span className="wg-result"><strong>{item.line}</strong>{item.benefits.map(benefit => <span key={benefit}>+ {benefit}</span>)}</span>
                </>}
              </button>
            </div>
          </div>;
        })}
      </div>}
      {selected && <footer className="wg-footer">
        <div className="wg-benefits">{selected.benefits.map(benefit => <span key={benefit}><Plus size={15} aria-hidden="true"/> {benefit}</span>)}</div>
        <a href="#contacto" className="action action-primary" onClick={() => modal.current?.close()}>Solicitar cotización</a>
      </footer>}
    </div>
  </dialog>;
}
