"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import { useReducedMotion } from "framer-motion";
import { IndustryPicker, industries, type Industry } from "./demo-industries";
import {
  AudioLines, BarChart3, Bot, CalendarDays, Check, Clapperboard, Facebook, Heart, Image as ImageIcon,
  Instagram, Layers3, MessageCircle, MessagesSquare, Network, Play, RotateCcw, ShoppingBag, UserRound, Users, X,
} from "lucide-react";

const scenes = [
  { id: "perfil", name: "Transformación de perfil", icon: UserRound },
  { id: "contenido", name: "Creación de contenido", icon: Layers3 },
  { id: "crecimiento", name: "Crecimiento de comunidad", icon: Users },
  { id: "agenda", name: "Calendario de contenido", icon: CalendarDays },
  { id: "mensajes", name: "Gestión de mensajes", icon: MessagesSquare },
  { id: "ventas", name: "Resultados comerciales", icon: BarChart3 },
] as const;
const networks = [
  { id: "instagram", name: "Instagram", icon: Instagram },
  { id: "facebook", name: "Facebook", icon: Facebook },
  { id: "tiktok", name: "TikTok", icon: AudioLines },
  { id: "whatsapp", name: "WhatsApp", icon: MessageCircle },
] as const;
type View = (typeof scenes)[number]["id"] | (typeof networks)[number]["id"];
const number = (value: number) => Math.round(value).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
const blend = (from: number, to: number, progress: number) => number(from + (to - from) * progress);
const formatOptions = [
  { id: "grafico", name: "Diseño gráfico", icon: ImageIcon },
  { id: "video", name: "Video corto", icon: Play },
  { id: "reel", name: "Reel", icon: Clapperboard },
  { id: "historia", name: "Historia", icon: Instagram },
] as const;
type MediaFormat = (typeof formatOptions)[number]["id"];

function Photo({ industry, index = 0 }: { industry: Industry; index?: number }) {
  const item = industries[industry];
  return <img src={"/galeria-web/" + item.photo + ".webp"} width={498} height={498} alt={item.posts[index]} style={{ objectPosition: (25 + index * 25) + "% center" }}/>;
}

function Reel({ industry }: { industry: Industry }) {
  const reduced = useReducedMotion();
  const item = industries[industry];
  return <video className="so-reel" aria-label={"Video vertical de muestra: " + item.brand} src={"/redes-sociales/" + industry + ".mp4"}
    poster={"/galeria-web/" + item.photo + ".webp"} muted playsInline loop autoPlay={!reduced} controls preload="metadata" />;
}

function Profile({ progress, industry, before = false }: { progress: number; industry: Industry; before?: boolean }) {
  const item = industries[industry];
  const branded = !before && progress > .24;
  const bio = !before && progress > .41;
  const highlights = !before && progress > .6;
  const curated = !before && progress > .76;
  return <section className="so-pane so-profile" aria-label={before ? "Perfil básico" : "Perfil de marca"}>
    <div className="so-pane-title"><Instagram size={17} aria-hidden="true"/> {before ? "Antes" : "Después"}<span>{branded ? "Perfil profesional" : "Perfil básico"}</span></div>
    <div className="so-profile-brand" data-branded={branded}>
      <div className="so-avatar">{branded ? <Photo industry={industry}/> : <UserRound size={28} aria-hidden="true"/>}</div>
      <div><strong>{branded ? item.brand : item.label + " local"}</strong><small>{branded ? "@" + item.handle : "@perfilbasico"}</small></div>
    </div>
    <p className="so-bio">{bio ? item.bio : "Consultas por mensaje."}</p>
    {highlights && <div className="so-highlights">{item.highlights.map((label, i) => <span key={label}><i><Photo industry={industry} index={i}/></i>{label}</span>)}</div>}
    <div className="so-feed" data-curated={curated}>
      {item.posts.map((title, index) => <figure key={title}>{curated ? <><Photo industry={industry} index={index}/><figcaption>{title}</figcaption></> : <ImageIcon size={22} aria-hidden="true"/>}</figure>)}
    </div>
  </section>;
}

function ContentStudio({ progress, industry, shortOnly = false }: { progress: number; industry: Industry; shortOnly?: boolean }) {
  const item = industries[industry];
  const [format, setFormat] = useState<MediaFormat>("grafico");
  const stages = ["Idea", "Diseño", "Publicación", "Resultados"];
  const selected = shortOnly ? "video" : format;
  const designed = shortOnly || progress > .2;
  const posted = shortOnly || progress > .56;
  return <div className="so-content">
    <ol className="so-content-flow">{stages.map((stage, i) => <li key={stage} data-on={progress >= i * .24}>
      {progress >= i * .24 ? <Check size={15} aria-hidden="true"/> : <span aria-hidden="true"/>}{stage}
    </li>)}</ol>
    {!shortOnly && <div className="so-formats" role="group" aria-label="Formatos de contenido">
      {formatOptions.map(({ id, name, icon: Icon }) => <button key={id} type="button" aria-pressed={format === id} onClick={() => setFormat(id)}><Icon size={16} aria-hidden="true"/>{name}</button>)}
    </div>}
    <div className="so-creative" key={selected} data-format={selected} data-ready={designed}>
      {!designed ? <div className="so-wireframe"><ImageIcon size={29} aria-hidden="true"/><span/><span/><span/></div>
        : selected === "video" || selected === "reel" ? <Reel industry={industry}/>
        : <figure><Photo industry={industry} index={selected === "historia" ? 1 : 0}/><figcaption>{selected === "historia" ? item.posts[1] : item.campaign}</figcaption></figure>}
      {posted && <div className="so-engagement">
        <span><Heart size={16} aria-hidden="true"/> {blend(0, 246, Math.max(0, (progress - .56) / .44))} Me gusta</span>
        <span><MessageCircle size={16} aria-hidden="true"/> {blend(0, 18, Math.max(0, (progress - .56) / .44))} comentarios</span>
      </div>}
    </div>
  </div>;
}

const milestones = [500, 2000, 10000, 25000];

function Community({ progress }: { progress: number }) {
  const point = progress * (milestones.length - 1);
  const index = Math.min(milestones.length - 2, Math.floor(point));
  const metrics = [
    ["Seguidores", blend(milestones[index], milestones[index + 1], point - index)],
    ["Alcance", blend(5000, 80000, progress)],
    ["Interacciones", blend(200, 7500, progress)],
  ];
  return <section className="so-pane so-community" aria-label="Crecimiento de comunidad">
    <div className="so-metrics">{metrics.map(([label, value]) => <div key={label}><span>{label}</span><strong>{value}</strong></div>)}</div>
    <svg viewBox="0 0 460 130" className="so-chart" role="img" aria-label="Curva ilustrativa de crecimiento de seguidores">
      <path className="so-chart-grid" d="M0 15H460 M0 48H460 M0 81H460 M0 114H460 M30 0V130 M160 0V130 M290 0V130 M420 0V130"/>
      <path pathLength="1" fill="none" strokeDasharray="1" strokeDashoffset={1 - progress} className="so-chart-line" d="M30 114C90 114 110 109 160 107S241 89 290 71S379 31 420 15"/>
    </svg>
    <ol className="so-milestones">{milestones.map((m, i) => <li key={m} data-on={point >= i}>{number(m)}</li>)}</ol>
  </section>;
}

const schedule = [
  { day: "Lun", date: "07", time: "09:00", type: "Publicación", icon: ImageIcon },
  { day: "Mar", date: "08", time: "12:30", type: "Historia", icon: Instagram },
  { day: "Mié", date: "09", time: "18:00", type: "Reel", icon: Clapperboard },
  { day: "Jue", date: "10", time: "10:00", type: "Publicación", icon: ImageIcon },
  { day: "Vie", date: "11", time: "16:00", type: "Historia", icon: Instagram },
];

function Calendar({ progress, industry }: { progress: number; industry: Industry }) {
  const [active, setActive] = useState(0);
  const slot = schedule[active];
  return <section className="so-pane so-calendar" aria-label="Agenda editorial">
    <div className="so-pane-title"><CalendarDays size={18} aria-hidden="true"/> Semana editorial<span><Bot size={15} aria-hidden="true"/> IA + Automatización</span></div>
    <div className="so-calendar-grid" role="group" aria-label="Publicaciones programadas">
      {schedule.map((entry, i) => <button key={entry.day} type="button" aria-pressed={active === i} data-on={progress > i * .16} onClick={() => setActive(i)}>
        <span>{entry.day} <strong>{entry.date}</strong></span><entry.icon size={19} aria-hidden="true"/><b>{entry.type}</b><small>{entry.time}</small>
      </button>)}
    </div>
    <div className="so-calendar-detail"><span><slot.icon size={20} aria-hidden="true"/>{industries[industry].posts[active % 3]}</span><strong>{slot.day} · {slot.time}</strong><span>{progress > active * .16 ? "✓ Programado" : "En preparación"}</span></div>
  </section>;
}

const threadTemplates = [
  { channel: "Comentario", status: "Respondido" },
  { channel: "Mensaje directo", status: "Cliente interesado" },
  { channel: "Instagram", status: "Cliente interesado" },
  { channel: "Facebook", status: "Respondido" },
  { channel: "WhatsApp", status: "Reunión programada" },
];

function Messages({ progress, industry, whatsapp = false }: { progress: number; industry: Industry; whatsapp?: boolean }) {
  const item = industries[industry];
  const threads = threadTemplates.map((thread, index) => ({
    ...thread,
    text: index === 0 ? "¡Me encanta esta publicación!" : index === 4 ? item.inquiry : item.signals[index % 3] + " · Consulta recibida",
    reply: index === 0 ? "¡Gracias por seguir a " + item.brand + "!" : index === 4 ? item.outcome + " en la demo para mañana a las 10:00." : item.reply,
  }));
  const [active, setActive] = useState<number>();
  const arrived = whatsapp ? threads : threads.slice(0, Math.min(5, 1 + Math.floor(progress * 5)));
  const current = active ?? (whatsapp ? 4 : arrived.length - 1);
  const selected = threads[current];
  const answered = progress > .14;
  const statuses = ["Respondido", "Cliente interesado", "Reunión programada"];
  return <div className="so-message-layout">
    <section className="so-pane" aria-label="Bandeja multicanal"><div className="so-pane-title"><MessagesSquare size={18} aria-hidden="true"/> Bandeja multicanal<span>{arrived.length} mensajes</span></div>
      <div className="so-inbox">{arrived.map((item, i) => <button type="button" key={item.channel} aria-pressed={current === i} onClick={() => setActive(i)}><strong>{item.channel}</strong><span>{item.text}</span></button>)}</div>
    </section>
    <section className="so-pane" aria-label="Conversación automatizada">
      <div className="so-pane-title"><Bot size={18} aria-hidden="true"/> {selected.channel}<span>Respuesta con IA</span></div>
      <div className="so-messages" key={selected.channel}><p>{selected.text}</p>{answered && <p><Bot size={16} aria-hidden="true"/>{selected.reply}</p>}</div>
      <ul className="so-message-status">{statuses.map((status, i) => <li key={status} data-on={answered && i <= statuses.indexOf(selected.status)}><Check size={15} aria-hidden="true"/>{status}</li>)}</ul>
    </section>
  </div>;
}

const sales = [
  { name: "Publicación", detail: "Reel publicado", icon: Clapperboard },
  { name: "Interacción", detail: "Reacción al contenido", icon: Heart },
  { name: "Mensaje", detail: "Consulta por DM", icon: MessageCircle },
  { name: "Lead", detail: "Contacto registrado", icon: UserRound },
  { name: "Venta", detail: "Pedido confirmado", icon: ShoppingBag },
];

function CommercialResults({ progress, industry }: { progress: number; industry: Industry }) {
  return <section className="so-pane so-sales" aria-label="Del contenido a la venta">
    <div className="so-pane-title"><Network size={18} aria-hidden="true"/> Del contenido a la venta</div>
    <ol>{sales.map(({ name, detail, icon: Icon }, i) => <li key={name} data-on={progress >= i * .22}><div><Icon size={22} aria-hidden="true"/></div><strong>{name}</strong><span>{i === 4 ? industries[industry].outcome : detail}</span></li>)}</ol>
  </section>;
}

function FacebookView({ progress, industry }: { progress: number; industry: Industry }) {
  const item = industries[industry];
  return <section className="so-pane so-facebook" aria-label="Facebook, campañas y comunidad">
    <div className="so-pane-title"><Facebook size={18} aria-hidden="true"/> Facebook<span>Campañas y comunidad</span></div>
    <div className="so-facebook-body"><figure><Photo industry={industry}/><figcaption>{item.offer} · Anuncio de muestra</figcaption></figure>
      <div><div className="so-metrics"><div><span>Reacciones</span><strong>{blend(0, 480, progress)}</strong></div><div><span>Comentarios</span><strong>{blend(0, 62, progress)}</strong></div></div>
      {progress > .32 && <p className="so-comment">{item.inquiry}</p>}
      {progress > .62 && <p className="so-comment"><Bot size={16} aria-hidden="true"/> {item.reply}</p>}</div>
    </div>
  </section>;
}

function SocialRun({ view, industry }: { view: View; industry: Industry }) {
  const reduced = useReducedMotion();
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    if (reduced) return;
    const start = performance.now();
    const timer = window.setInterval(() => {
      const next = Math.min(1, (performance.now() - start) / 4900);
      setProgress(next);
      if (next === 1) window.clearInterval(timer);
    }, 45);
    return () => window.clearInterval(timer);
  }, [reduced]);
  const value = reduced ? 1 : progress;
  return <div className="so-run">
    <div className="mk-progress" role="progressbar" aria-label="Progreso de la demostración" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(value * 100)}><i style={{ width: value * 100 + "%" }}/></div>
    {view === "perfil" && <div className="so-profile-grid"><Profile industry={industry} progress={0} before/><Profile industry={industry} progress={value}/></div>}
    {view === "contenido" && <ContentStudio industry={industry} progress={value}/>}
    {view === "crecimiento" && <Community progress={value}/>}
    {view === "agenda" && <Calendar industry={industry} progress={value}/>}
    {view === "mensajes" && <Messages industry={industry} progress={value}/>}
    {view === "ventas" && <CommercialResults industry={industry} progress={value}/>}
    {view === "instagram" && <Profile industry={industry} progress={1}/>}
    {view === "facebook" && <FacebookView industry={industry} progress={value}/>}
    {view === "tiktok" && <ContentStudio industry={industry} progress={value} shortOnly/>}
    {view === "whatsapp" && <Messages industry={industry} progress={value} whatsapp/>}
    <span className="sr-only" role="status">{value === 1 ? "Demostración completada" : ""}</span>
  </div>;
}

export default function SocialLab({ onClose, industry, onIndustry }: { onClose: () => void; industry: Industry; onIndustry: (value: Industry) => void }) {
  const modal = useRef<HTMLDialogElement>(null);
  const [view, setView] = useState<View>("perfil");
  const [replay, setReplay] = useState(0);
  useEffect(() => {
    const dialog = modal.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);
  return <dialog className="ai-lab so-lab" ref={modal} aria-labelledby="so-title" onClose={onClose}>
    <div className="ai-lab-inner">
      <div className="mk-orb" aria-hidden="true"/>
      <header className="ai-lab-header">
        <div className="ai-lab-symbol"><Network size={24} aria-hidden="true"/></div>
        <div className="ai-lab-title"><h2 id="so-title">Redes sociales</h2><p>Evolución de marca · Datos simulados</p></div>
        <button type="button" className="ai-lab-icon" aria-label="Repetir demostración" onClick={() => setReplay(replay + 1)}><RotateCcw size={18} aria-hidden="true"/></button>
        <button type="button" className="ai-lab-icon" aria-label="Cerrar redes sociales" onClick={() => modal.current?.close()}><X size={21} aria-hidden="true"/></button>
      </header>
      <IndustryPicker industry={industry} onChange={onIndustry}/>
      <div className="so-scenes" role="group" aria-label="Escenarios de redes sociales">
        {scenes.map(({ id, name, icon: Icon }) => <button key={id} type="button" aria-pressed={view === id} onClick={() => setView(id)}><Icon size={16} aria-hidden="true"/>{name}</button>)}
      </div>
      <div className="so-networks" role="group" aria-label="Vista por red social">
        {networks.map(({ id, name, icon: Icon }) => <button key={id} type="button" aria-pressed={view === id} onClick={() => setView(id)} onPointerEnter={event => { if (event.pointerType === "mouse") setView(id); }}><Icon size={16} aria-hidden="true"/>{name}</button>)}
      </div>
      <SocialRun key={industry + view + replay} view={view} industry={industry}/>
    </div>
  </dialog>;
}
