"use client";

import { useEffect, useRef, useState } from "react";
import { Bell, Bot, CalendarDays, Check, Clock3, Database, FileText, Gauge, Mail, MessageCircle, Pause, Play, RotateCcw, ScanLine, Target, TrendingUp, UserRound, Workflow, X, type LucideIcon } from "lucide-react";
import { useReducedMotion } from "framer-motion";

type Step = { label: string; output: string; icon: LucideIcon; metric?: "lead" | "meeting" | "opportunity" };
type Scenario = { id: string; title: string; channel: string; message: string; icon: LucideIcon; steps: Step[] };

const scenarios: Scenario[] = [
  {
    id: "whatsapp", title: "Atención por WhatsApp", channel: "WhatsApp",
    message: "Hola, quisiera información.", icon: MessageCircle,
    steps: [
      { label: "IA responde el mensaje", icon: Bot, output: "¡Hola! Puedo ayudarte. ¿Qué servicio te interesa?" },
      { label: "Lead registrado", icon: UserRound, output: "Origen del prospecto · WhatsApp", metric: "lead" },
      { label: "Datos guardados en CRM", icon: Database, output: "Contacto de demostración · CRM" },
      { label: "Correo enviado automáticamente", icon: Mail, output: "Asunto · Información sobre nuestros servicios" },
      { label: "Reunión sugerida", icon: CalendarDays, output: "Propuesta · Reunión de 20 minutos", metric: "meeting" },
    ],
  },
  {
    id: "cotizacion", title: "Solicitud de cotización", channel: "Formulario web",
    message: "Quiero una página web.", icon: FileText,
    steps: [
      { label: "Analiza la consulta", icon: ScanLine, output: "Intención detectada · Solicitud de cotización" },
      { label: "Clasifica el prospecto", icon: UserRound, output: "Categoría · Desarrollo web", metric: "lead" },
      { label: "Asigna prioridad", icon: Gauge, output: "Alta · Solicitud de propuesta" },
      { label: "Notifica al equipo", icon: Bell, output: "Destino · Equipo comercial" },
      { label: "Programa seguimiento", icon: Clock3, output: "Recordatorio · Mañana a las 10:00" },
    ],
  },
  {
    id: "ventas", title: "Automatización de ventas", channel: "Chat web",
    message: "Hola, me interesa conseguir más clientes.", icon: TrendingUp,
    steps: [
      { label: "Mensaje entrante", icon: MessageCircle, output: "Consulta comercial recibida · Chat web", metric: "lead" },
      { label: "La IA responde", icon: Bot, output: "¡Hola! ¿En qué sector trabaja tu empresa?" },
      { label: "Se recomienda un servicio", icon: Target, output: "Servicio sugerido · Campañas de captación" },
      { label: "Se agenda una reunión", icon: CalendarDays, output: "Reserva de demostración · Mañana a las 14:00", metric: "meeting" },
      { label: "Se registra la oportunidad", icon: Database, output: "Etapa comercial · Reunión agendada", metric: "opportunity" },
    ],
  },
];

const stepDuration = 900;

function WorkflowRun({ scenario }: { scenario: Scenario }) {
  const [completed, setCompleted] = useState(0);
  const [paused, setPaused] = useState(false);
  const [inspection, setInspection] = useState<number>();
  const reduced = useReducedMotion();
  const finished = completed === scenario.steps.length;
  const events = scenario.steps.slice(0, completed);
  const latest = scenario.steps[inspection ?? (completed - 1)];
  const state = finished ? "Completado" : paused ? "En pausa" : "En ejecución";

  useEffect(() => {
    if (paused || finished) return;
    const timer = window.setTimeout(() => setCompleted(completed + 1), stepDuration);
    return () => window.clearTimeout(timer);
  }, [completed, finished, paused]);

  const metrics = [
    { label: "Tareas automatizadas", value: completed + "/" + scenario.steps.length },
    { label: "Tiempo de ejecución", value: (completed * stepDuration / 1000).toFixed(1).replace(".", ",") + " s" },
    { label: "Prospectos", value: events.filter(event => event.metric === "lead").length },
  ];
  if (scenario.id !== "cotizacion") {
    metrics.push({
      label: scenario.id === "ventas" ? "Reuniones agendadas" : "Reuniones sugeridas",
      value: events.filter(event => event.metric === "meeting").length,
    });
  }
  if (scenario.id === "ventas") {
    metrics.push({ label: "Oportunidades", value: events.filter(event => event.metric === "opportunity").length });
  }

  return <>
    <div className="au-run-bar">
      <p data-state={state}><i aria-hidden="true"/>{state}</p>
      {!finished && <button type="button" className="au-control" onClick={() => setPaused(!paused)}>
        {paused ? <Play size={16} aria-hidden="true"/> : <Pause size={16} aria-hidden="true"/>} {paused ? "Reanudar" : "Pausar"}
      </button>}
    </div>
    <div className="au-grid">
      <section className="ai-lab-panel au-message" aria-label="Mensaje entrante">
        <div className="ai-panel-heading"><scenario.icon size={18} aria-hidden="true"/> {scenario.channel} <span>Mensaje entrante</span></div>
        <blockquote>{scenario.message}</blockquote>
      </section>
      <section className="ai-lab-panel au-pipeline" aria-label="Flujo automático">
        <div className="ai-panel-heading"><Workflow size={18} aria-hidden="true"/> Flujo automático <span>{completed}/{scenario.steps.length}</span></div>
        <ol className="au-nodes" data-paused={paused || Boolean(reduced)}>
          {scenario.steps.map(({ label, icon: Icon }, index) => {
            const done = index < completed;
            const active = index === completed;
            return <li key={label} data-status={done ? "done" : active ? "active" : "pending"}>
              <button type="button" disabled={!done} aria-pressed={done ? inspection === index : undefined} onClick={() => setInspection(inspection === index ? undefined : index)}>
                <span className="au-node-icon"><Icon size={17} aria-hidden="true"/></span>
                <span>{label}</span>
                <span className="au-node-status">{done ? <><Check size={17} aria-hidden="true"/><span className="sr-only">Completado</span></> : <span className="sr-only">{active ? "En curso" : "Pendiente"}</span>}</span>
              </button>
            </li>;
          })}
        </ol>
      </section>
      <section className="ai-lab-panel au-events" aria-label="Salida del flujo">
        <div className="ai-panel-heading"><Database size={18} aria-hidden="true"/> Salida del flujo</div>
        <div className="au-event" role="status">
          {latest ? <><strong>{latest.label}</strong><p>{latest.output}</p></> : <p>Procesando mensaje…</p>}
        </div>
      </section>
      <section className="ai-lab-panel au-metrics" aria-label="Métricas de simulación">
        <div className="ai-panel-heading"><TrendingUp size={18} aria-hidden="true"/> Métricas en tiempo real</div>
        <dl>{metrics.map(({ label, value }) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
      </section>
    </div>
  </>;
}

export default function AutomationLab({ onClose }: { onClose: () => void }) {
  const modal = useRef<HTMLDialogElement>(null);
  const [scenario, setScenario] = useState(scenarios[0]);
  const [replay, setReplay] = useState(0);

  useEffect(() => {
    const dialog = modal.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);

  return <dialog className="ai-lab au-lab" ref={modal} aria-labelledby="au-title" onClose={onClose}>
    <div className="ai-lab-inner">
      <header className="ai-lab-header">
        <div className="ai-lab-symbol"><Workflow size={24} aria-hidden="true"/></div>
        <div className="ai-lab-title"><h2 id="au-title">Automatización</h2><p>Simulación interactiva</p></div>
        <button type="button" className="ai-lab-icon" aria-label="Repetir flujo" onClick={() => setReplay(replay + 1)}><RotateCcw size={18} aria-hidden="true"/></button>
        <button type="button" className="ai-lab-icon" aria-label="Cerrar automatización" onClick={() => modal.current?.close()}><X size={21} aria-hidden="true"/></button>
      </header>
      <div className="ai-scenarios au-scenarios" role="group" aria-label="Escenarios de automatización">
        {scenarios.map(item => <button type="button" key={item.id} aria-pressed={scenario.id === item.id} onClick={() => setScenario(item)}>
          <item.icon size={16} aria-hidden="true"/> {item.title}
        </button>)}
      </div>
      <WorkflowRun key={scenario.id + replay} scenario={scenario}/>
    </div>
  </dialog>;
}
