"use client";

import { Activity, Bell, Bot, CalendarDays, Check, CircleDot, CirclePlay, Database, MessageCircle, Radar, RotateCcw, ScanLine, UserRound, Workflow, X } from "lucide-react";
import { useReducedMotion } from "framer-motion";
import { useEffect, useRef, useState } from "react";

const scenarios = [
  {
    id: "atencion", label: "Atención automática", icon: MessageCircle, panel: "Canal de atención",
    customer: "¿Qué servicios ofrecen?",
    answer: "Ofrecemos desarrollo web, automatización con IA, gestión de redes sociales y publicidad digital. ¿Qué tipo de negocio tienes?",
  },
  {
    id: "calificacion", label: "Calificación de prospectos", icon: UserRound, panel: "Análisis del prospecto",
    customer: "Tengo una empresa de construcción.",
    answer: "Perfecto. Según tu sector, te recomiendo una página web profesional y campañas de captación de clientes. ¿Cuántos proyectos realizas al mes?",
  },
  {
    id: "reserva", label: "Reserva automática", icon: CalendarDays, panel: "Calendario de disponibilidad",
    customer: "Quiero una reunión.",
    answer: "Tengo disponibilidad mañana a las 10:00, 14:00 y 16:00. ¿Qué horario prefieres?",
  },
  {
    id: "flujo", label: "Automatización interna", icon: Workflow, panel: "Flujo de trabajo",
    customer: "Me interesa la propuesta. ¿Pueden hacer seguimiento?",
    answer: "Claro. Estoy registrando tu solicitud y preparando el seguimiento con nuestro equipo.",
  },
  {
    id: "analisis", label: "Análisis de negocio", icon: Radar, panel: "Diagnóstico digital",
    customer: "¿Cómo podemos mejorar nuestra visibilidad?",
    answer: "He detectado que tu empresa no aparece en los primeros resultados de búsqueda. Recomiendo una estrategia SEO y campañas digitales.",
  },
] as const;

type Scenario = (typeof scenarios)[number];
const times = ["10:00", "14:00", "16:00"];
const workflow = [
  { label: "Lead registrado", icon: UserRound },
  { label: "Contacto guardado en CRM", icon: Database },
  { label: "Seguimiento programado", icon: CalendarDays },
  { label: "Notificación enviada al equipo", icon: Bell },
];

function AnalysisPanel() {
  return <div className="ai-analytics">
    <p>Indicadores ilustrativos</p>
    <svg viewBox="0 0 280 110" role="img" aria-label="Tendencia ilustrativa de visibilidad baja en buscadores">
      <path className="ai-chart-grid" d="M4 24H276M4 49H276M4 74H276M4 99H276M40 8V102M100 8V102M160 8V102M220 8V102"/>
      <path className="ai-chart-area" d="M4 83L49 78L93 86L139 62L185 70L231 55L276 62V102H4Z"/>
      <path className="ai-chart-line" pathLength={1} d="M4 83L49 78L93 86L139 62L185 70L231 55L276 62"/>
    </svg>
    <dl className="ai-insights"><div><dt>Búsqueda orgánica</dt><dd>Baja visibilidad</dd></div><div><dt>Acción prioritaria</dt><dd>SEO + campañas digitales</dd></div></dl>
  </div>;
}

function ScenarioRun({ scenario }: { scenario: Scenario }) {
  const reduced = useReducedMotion();
  const [elapsed, setElapsed] = useState(0);
  const [slot, setSlot] = useState<string>();
  const stepTime = 13;
  const customerStart = 160;
  const answerStart = customerStart + scenario.customer.length * stepTime + 480;
  const completeAt = answerStart + scenario.answer.length * stepTime;
  const stopAt = Math.max(completeAt, answerStart + 1800);

  useEffect(() => {
    if (reduced) return;
    const started = performance.now();
    const timer = window.setInterval(() => {
      const next = Math.min(stopAt, performance.now() - started);
      setElapsed(next);
      if (next === stopAt) window.clearInterval(timer);
    }, 32);
    return () => window.clearInterval(timer);
  }, [reduced, stopAt]);

  const time = reduced ? stopAt : elapsed;
  const customerText = scenario.customer.slice(0, Math.max(0, Math.floor((time - customerStart) / stepTime)));
  const answerText = scenario.answer.slice(0, Math.max(0, Math.floor((time - answerStart) / stepTime)));
  const flowDone = Math.max(0, Math.min(workflow.length, Math.floor((time - answerStart) / 430) + 1));
  const answerDone = time >= completeAt;
  const isAnalyzing = time >= answerStart;

  return <div className="ai-lab-panels">
    <section className="ai-lab-panel" aria-label="Conversación simulada">
      <div className="ai-panel-heading"><MessageCircle size={18} aria-hidden="true"/> Conversación</div>
      <div className="ai-chat-track">
        {customerText && <div className="ai-bubble ai-bubble-customer" aria-hidden="true"><span>Cliente</span>{customerText}</div>}
        {time > answerStart - 400 && <div className="ai-bubble ai-bubble-agent" aria-hidden="true">
          <span><Bot size={14}/> Agente IA</span>
          {answerText}{!answerDone && <i className="ai-type-cursor"/>}
        </div>}
        {slot && <div className="ai-bubble ai-bubble-agent"><span><Bot size={14} aria-hidden="true"/> Agente IA</span>Reserva simulada para mañana a las {slot}.</div>}
        <div className="sr-only" role="log" aria-live="polite">
          {customerText === scenario.customer && <p>Cliente: {scenario.customer}</p>}
          {answerDone && <p>Agente IA: {scenario.answer}</p>}
          {slot && <p>Reserva simulada para mañana a las {slot}.</p>}
        </div>
      </div>
    </section>
    <section className="ai-lab-panel" aria-label={scenario.panel}>
      <div className="ai-panel-heading"><scenario.icon size={18} aria-hidden="true"/> {scenario.panel}</div>
      <div className="ai-panel-content">
        {scenario.id === "atencion" && <dl className="ai-insights">
          <div><dt>Intención</dt><dd>{isAnalyzing ? "Consulta de servicios" : "Esperando mensaje"}</dd></div>
          <div><dt>Siguiente paso</dt><dd>{answerDone ? "Identificar el tipo de negocio" : "En preparación"}</dd></div>
        </dl>}
        {scenario.id === "calificacion" && <dl className="ai-insights">
          <div><dt>Sector detectado</dt><dd>{isAnalyzing ? "Construcción" : "Analizando"}</dd></div>
          <div><dt>Solución sugerida</dt><dd>{isAnalyzing ? "Desarrollo web y captación" : "En evaluación"}</dd></div>
          <div><dt>Estado del prospecto</dt><dd>{answerDone ? "Pendiente de confirmar volumen mensual" : "En calificación"}</dd></div>
        </dl>}
        {scenario.id === "reserva" && <div className="ai-calendar">
          <p><CalendarDays size={18} aria-hidden="true"/> Mañana</p>
          <div className="ai-time-grid" aria-label="Horarios simulados">
            {times.map(timeOption => <button type="button" key={timeOption} disabled={!answerDone} aria-pressed={slot === timeOption} onClick={() => setSlot(timeOption)}>{timeOption}</button>)}
          </div>
          {slot && <div className="ai-selected"><Check size={16} aria-hidden="true"/> {slot} · Horario seleccionado</div>}
        </div>}
        {scenario.id === "flujo" && <ol className="ai-workflow">
          {workflow.map(({ label, icon: Icon }, index) => {
            const done = index < flowDone;
            return <li key={label} data-done={done}>
              {done ? <Check size={16} aria-hidden="true"/> : <Icon size={16} aria-hidden="true"/>}
              <span>{label}</span><span className="sr-only">{done ? "Completado" : "Pendiente"}</span>
            </li>;
          })}
        </ol>}
        {scenario.id === "analisis" && (isAnalyzing ? <AnalysisPanel/> : <p className="ai-lab-pending"><ScanLine size={19} aria-hidden="true"/> Analizando la consulta…</p>)}
      </div>
    </section>
  </div>;
}

type AiView = "video" | "simulation";

export default function AiLab({ initialView, onClose }: { initialView: AiView; onClose: () => void }) {
  const modal = useRef<HTMLDialogElement>(null);
  const [view, setView] = useState(initialView);
  const [selected, setSelected] = useState<Scenario>(scenarios[0]);
  const [replay, setReplay] = useState(0);

  useEffect(() => {
    const dialog = modal.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);

  return <dialog id="ai-lab" className="ai-lab" ref={modal} aria-labelledby="ai-lab-title" onClose={onClose}>
    <div className="ai-lab-inner">
      <header className="ai-lab-header">
        <div className="ai-lab-symbol"><Activity size={24} aria-hidden="true"/></div>
        <div className="ai-lab-title"><h2 id="ai-lab-title">IA en acción</h2><p><CircleDot size={12} aria-hidden="true"/> Demostración</p></div>
        <button type="button" className="ai-lab-icon" aria-label="Cerrar demostración de IA" onClick={() => modal.current?.close()}><X size={21}/></button>
      </header>
      <nav className="ai-scenarios" aria-label="Demostración de IA">
        <button type="button" aria-pressed={view === "video"} onClick={() => setView("video")}>
          <CirclePlay size={16} aria-hidden="true"/> Video de ejemplo
        </button>
        <button type="button" aria-pressed={view === "simulation"} onClick={() => setView("simulation")}>
          <Bot size={16} aria-hidden="true"/> Simulación interactiva
        </button>
      </nav>
      {view === "video" ? (
        <video
          className="ai-example-video"
          controls
          playsInline
          preload="metadata"
          poster="/proyectos/ia-video-ejemplo.webp"
          aria-label="Video de ejemplo de IA"
        >
          <source src="/proyectos/ia-video-ejemplo.mp4" type="video/mp4"/>
          Tu navegador no puede reproducir este video.
        </video>
      ) : (
        <>
          <div className="ai-scenarios" role="group" aria-label="Escenarios">
            {scenarios.map(scenario => <button type="button" key={scenario.id} aria-pressed={selected.id === scenario.id} onClick={() => setSelected(scenario)}>
              <scenario.icon size={16} aria-hidden="true"/> {scenario.label}
            </button>)}
          </div>
          <div className="ai-stage-title">
            <h3>{selected.label}</h3>
            <button type="button" className="ai-lab-icon" aria-label="Repetir escenario" onClick={() => setReplay(replay + 1)}><RotateCcw size={17}/></button>
          </div>
          <ScenarioRun key={selected.id + replay} scenario={selected}/>
        </>
      )}
    </div>
  </dialog>;
}
