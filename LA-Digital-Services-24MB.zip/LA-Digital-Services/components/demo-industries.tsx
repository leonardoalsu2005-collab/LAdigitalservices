import { Building2, CarFront, ExternalLink, Utensils } from "lucide-react";

export const industries = {
  edificio: {
    label: "Inmobiliaria", brand: "Torre Vértice", handle: "torrevertice", icon: Building2, color: "#a9cf94", photo: "edificio",
    source: "Macororó 16 | 17", href: "https://www.macororo.com/en-desarrollo/macororo-16-17",
    hero: "Tu próximo hogar, encima de la ciudad.", campaign: "Descubrí tu próximo departamento", offer: "Residencias y amenidades", action: "Agendar visita",
    bio: "Departamentos, vistas urbanas y espacios para todos los días.", highlights: ["Torre", "Amenidades", "Visitas"],
    posts: ["Vistas de la ciudad", "Recorrido por la torre", "Agenda de visitas"],
    inquiry: "¿Tienen departamentos de dos dormitorios?", reply: "Sí. En esta demo podés elegir una tipología y agendar una visita.",
    outcome: "Visita agendada", signals: ["Solicitó una visita", "Consultó por dos dormitorios", "Exploró la torre"],
  },
  vehiculos: {
    label: "Concesionaria", brand: "Nova Motors", handle: "novamotors", icon: CarFront, color: "#92c9ff", photo: "vehiculos",
    source: "BMW Bolivia", href: "https://www.bmw.bo/",
    hero: "Tu próximo auto empieza aquí.", campaign: "Conocé la nueva colección", offer: "Showroom y pruebas de manejo", action: "Agendar prueba",
    bio: "Vehículos, asesoría y pruebas de manejo en un solo lugar.", highlights: ["Modelos", "Showroom", "Pruebas"],
    posts: ["Modelo destacado", "Desde el showroom", "Prueba de manejo"],
    inquiry: "¿Puedo hacer una prueba de manejo?", reply: "Sí. En esta demo podés elegir el modelo y coordinar una prueba de manejo.",
    outcome: "Prueba agendada", signals: ["Pidió una prueba de manejo", "Consultó por un SUV", "Exploró el catálogo"],
  },
  restaurante: {
    label: "Restaurante", brand: "Brasa & Olivo", handle: "brasayolivo", icon: Utensils, color: "#d99b5e", photo: "restaurante",
    source: "Central Restaurante", href: "https://centralrestaurante.com.pe/reservations",
    hero: "Una mesa, una noche especial.", campaign: "Una noche para compartir", offer: "Menú de temporada", action: "Reservar mesa",
    bio: "Cocina de temporada, menús de degustación y reservas en línea.", highlights: ["Menú", "Experiencias", "Reservas"],
    posts: ["Plato de temporada", "Detrás de la cocina", "Reservá tu mesa"],
    inquiry: "¿Tienen una mesa para dos?", reply: "Sí. En esta demo podés elegir la fecha y un horario para dos personas.",
    outcome: "Mesa reservada", signals: ["Solicitó una reserva", "Consultó por el menú", "Visitó la página"],
  },
} as const;
export type Industry = keyof typeof industries;

export function DemoReference({ industry }: { industry: Industry }) {
  const item = industries[industry];
  return <a className="industry-ref" href={item.href} target="_blank" rel="noreferrer">
    Referencia · {item.source}<ExternalLink size={13} aria-hidden="true"/>
  </a>;
}

export function IndustryPicker({ industry, onChange }: { industry: Industry; onChange: (value: Industry) => void }) {
  return <div className="industry-picker">
    <div role="group" aria-label="Tipo de negocio">
      {(Object.keys(industries) as Industry[]).map(id => {
        const { icon: Icon, label } = industries[id];
        return <button type="button" key={id} aria-pressed={industry === id} onClick={() => onChange(id)}><Icon size={16} aria-hidden="true"/>{label}</button>;
      })}
    </div>
    <DemoReference industry={industry}/>
  </div>;
}
