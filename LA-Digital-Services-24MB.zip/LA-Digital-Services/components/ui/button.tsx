import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { AnchorHTMLAttributes, ButtonHTMLAttributes } from "react";

const buttonVariants = cva("action", {
  variants: {
    variant: { primary: "action-primary", outline: "action-outline" },
    size: { default: "", small: "action-small" },
  },
  defaultVariants: { variant: "primary", size: "default" },
});

type Style = VariantProps<typeof buttonVariants>;

export function Button({ className, variant, size, asChild, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & Style & { asChild?: boolean }) {
  const Component = asChild ? Slot : "button";
  return <Component {...props} className={buttonVariants({ variant, size, className })} />;
}

export function ButtonLink({ className, variant, size, ...props }: AnchorHTMLAttributes<HTMLAnchorElement> & Style) {
  return <Button asChild className={className} variant={variant} size={size}><a {...props} /></Button>;
}
