"use client";

import { useEffect, useRef, useState } from "react";

export default function SiteIntro() {
  const [complete, setComplete] = useState(false);
  const screen = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (complete || !screen.current) return;

    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const hasDeepLink = window.location.hash && window.location.hash !== "#inicio";
    if (motion.matches || hasDeepLink || getComputedStyle(screen.current).visibility === "hidden") {
      setComplete(true);
      return;
    }

    const page = document.getElementById("site-page");
    const html = document.documentElement;
    page?.setAttribute("inert", "");
    html.classList.add("site-intro-active");

    const finish = () => setComplete(true);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") finish();
    };
    const onMotion = (event: MediaQueryListEvent) => {
      if (event.matches) finish();
    };
    const timeout = window.setTimeout(finish, 2700);
    window.addEventListener("keydown", onKey);
    motion.addEventListener("change", onMotion);

    return () => {
      window.clearTimeout(timeout);
      window.removeEventListener("keydown", onKey);
      motion.removeEventListener("change", onMotion);
      page?.removeAttribute("inert");
      html.classList.remove("site-intro-active");
    };
  }, [complete]);

  if (complete) return null;

  return (
    <div
      ref={screen}
      className="site-intro"
      onAnimationEnd={event => {
        if (event.target === event.currentTarget && event.animationName === "site-intro-exit") {
          setComplete(true);
        }
      }}
    >
      <div className="site-intro-grid" aria-hidden="true" />
      <div className="site-intro-scene">
        <span className="site-intro-orbit" aria-hidden="true" />
        <span className="site-intro-orbit site-intro-orbit-secondary" aria-hidden="true" />
        <div className="site-intro-frame">
          <div className="site-intro-logo" role="img" aria-label="LA Digital Services" />
        </div>
      </div>
    </div>
  );
}
