import { spawn } from "node:child_process";

const args = process.argv.slice(2).filter(arg => arg !== "--strictPort").map(arg => arg === "--host" ? "--hostname" : arg);
const child = spawn(process.execPath, ["node_modules/next/dist/bin/next", "dev", ...args], { stdio: "inherit" });
child.once("exit", code => { process.exitCode = code ?? 1; });
